/*
 * snake_repair.h
 *
 *  Created on: Sep 10, 2022
 *      Author: carrolls
 */

#ifndef INC_SNAKE_REPAIR_H_
#define INC_SNAKE_REPAIR_H_

void snake_game_cleanup(snake_game* s);

#endif /* INC_SNAKE_REPAIR_H_ */
