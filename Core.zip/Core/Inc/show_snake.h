/*
 * show_snake.h
 *
 *  Created on: Sep 10, 2022
 *      Author: carrolls
 */

#ifndef INC_SHOW_SNAKE_H_
#define INC_SHOW_SNAKE_H_

#include "snake_gameplay.h"

void incremental_show_snake(const snake_game* s, bool board_updated);


#endif /* INC_SHOW_SNAKE_H_ */
